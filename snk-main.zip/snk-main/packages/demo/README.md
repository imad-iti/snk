# @snk/demo

Contains various demo to test and validate some pieces of the algorithm.
