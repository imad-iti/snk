# @snk/github-user-contribution-service

Expose github-user-contribution as an endpoint. hosted on cloudflare

```sh


# deploy
bunx wrangler deploy --branch=production

# change secret
bunx wrangler secret put GITHUB_TOKEN

```
